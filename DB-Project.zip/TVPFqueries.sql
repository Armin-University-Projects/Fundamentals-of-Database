use [ArtStore];

/* Tiggers */

drop trigger if exists NewOrder;
go
create trigger NewOrder on [Order] 
for insert as
begin
	if exists (
	select 1 
	from inserted
	where FinalPrice != TotalPrice - Discount
	)
	begin
		raiserror('Invalid price', 10, 1);
	end
end
go

drop trigger if exists paymentReq;
go
create trigger paymentReq on Payment
after insert as
begin
	if exists (
	select 1 
	from inserted
	where IsCompleted = 1 and CompletionDate = null
	)
	begin
		raiserror('Invalid payment', 10, 1);
	end
end	
go


/* Views */

drop view if exists userPayments;
go
create view userPayments as
select [User].Id as [user_id], UserName as username, Price, [Description]
from Payment join [User] on UserId = [User].Id;
go

drop view if exists artists_artworks;
go
create view artists_artworks as
select Artist.Id as [artist_id], Nickname, [Name] as artwork
from Artist join Artwork on ArtistId = Artist.Id;
go


/* Procedures */

drop procedure if exists users_signup_ondate;
go
create procedure users_signup_ondate @date date 
as
select * from [User]
where @date = SignupDate
go

drop procedure if exists Artworks_ofStyle;
go
create procedure Artworks_ofStyle @style nvarchar(100)
as
select * from Artwork
where Style = @style
go


/* Functions */

drop function if exists lessExpensiveArtworks;
go
create function lessExpensiveArtworks (
	@price decimal(15,2)
)
returns table as
return 
	select *
	from Artwork
	where Price < @price;
go

drop function if exists moreExpensiveArtworks;
go
create function moreExpensiveArtworks (
	@price decimal(15,2)
)
returns table as
return 
	select *
	from Artwork
	where Price > @price;
go