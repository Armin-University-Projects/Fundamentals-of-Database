use [ArtStore];

/* update table */

alter table Artist
add Email nvarchar(255);

alter table [Artwork]
alter column [Description] nvarchar(255);

/* update rows */

update Person
set Birthdate = (year(getdate()) - 14)-(month(getdate()))-(day(getdate()))
where year(getdate()) - year(Birthdate) < 14;

update Artist
set Deathdate = GETDATE()
from Artist join Person on PersonId = Person.Id
where year(getdate()) - year(Birthdate) >= 100;

/* delete rows */

delete from Payment
where IsCompleted = 1 and CompletionDate = null;

delete from [Order]
where year(getdate()) - year(CreationDate) > 10;