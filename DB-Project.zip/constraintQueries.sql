use [ArtStore];

/* add constraints*/

alter table [Artwork]
add constraint priceRange check (price <= 10000000000);

alter table [Artwork]
add constraint ArtworkYearRange check (year([CreationDate]) > 1000);

alter table [Order]
add constraint OrderYearRange check (year([CreationDate]) > year(getdate()) - 40);

/* delete constraints */

alter table [Payment]
drop constraint df;

alter table [User]
drop constraint dotcom;

/* update constraints */

alter table [Artist]
drop constraint haveArtwork;
alter table [Artist]
add constraint haveArtwork check ([ArtworkCount] >= 3);

alter table [Person]
drop constraint ageLimit;
alter table [Person]
add constraint ageLimit check (year(getdate()) - year(birthdate) > 14);