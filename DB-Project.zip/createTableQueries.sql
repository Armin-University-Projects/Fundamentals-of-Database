if db_id('ArtStore') is not null
drop database [ArtStore];
create database [ArtStore];

use [ArtStore];

CREATE TABLE [Person] (
	Id BIGINT PRIMARY KEY NOT NULL,
	FirstName NVARCHAR(100) NOT NULL,
	LastName NVARCHAR(100) NOT NULL,
	Gender NVARCHAR(10) NOT NULL constraint genderLimit check (Gender in ('male', 'female')),
	Birthdate DATE NOT NULL constraint ageLimit check (Birthdate < getdate()),
)

CREATE TABLE [Artist] (
	Id BIGINT PRIMARY KEY NOT NULL,
	PersonId BIGINT FOREIGN KEY REFERENCES [Person](Id) NOT NULL,
	NickName NVARCHAR(100),
	Style NVARCHAR(100),
	ArtWorkCount NVARCHAR(10) NOT NULL constraint haveArtwork check (ArtworkCount > 0),
	Deathdate DATE default null,
)

CREATE TABLE [User] (
	Id BIGINT PRIMARY KEY NOT NULL,
	PersonId BIGINT FOREIGN KEY REFERENCES [Person](Id) NOT NULL,
	UserName NVARCHAR(100) NOT NULL,
	Email NVARCHAR(150) NOT NULL constraint dotcom check (right(Email, 4) = '.com'),
	Password NVARCHAR(50) NOT NULL,
	SignupDate DATE NOT NULL,
)

CREATE TABLE [ArtCategory] (
	Id BIGINT PRIMARY KEY NOT NULL,
	Name NVARCHAR(100) NOT NULL,
	AdditionDate DATE NOT NULL default getdate(),
)

CREATE TABLE [ArtSubCategory] (
	Id BIGINT PRIMARY KEY NOT NULL,
	CategoryId BIGINT FOREIGN KEY REFERENCES [ArtCategory](Id) NOT NULL,
	Name NVARCHAR(100) NOT NULL,
	AdditionDate DATE NOT NULL default getdate(),
)

CREATE TABLE [Artwork] (
	Id BIGINT PRIMARY KEY NOT NULL,
	ArtistId BIGINT FOREIGN KEY REFERENCES [Artist](Id) NOT NULL,
	CategoryId BIGINT FOREIGN KEY REFERENCES [ArtCategory](Id) NOT NULL,
	SubCategoryId BIGINT FOREIGN KEY REFERENCES [ArtSubCategory](Id) NOT NULL,
	Name NVARCHAR(100) NOT NULL,
	Price DECIMAL(15, 2) NOT NULL,
	Description NVARCHAR(150) NOT NULL,
	Style NVARCHAR(100) NOT NULL,
	Cover NVARCHAR(100) NOT NULL,
	AdditionDate DATE default getdate(),
	CreationDate DATE,
)

CREATE TABLE [Order] (
	Id BIGINT PRIMARY KEY NOT NULL,
	UserId BIGINT FOREIGN KEY REFERENCES [User](Id) NOT NULL,
	FinalPrice DECIMAL(15, 2) NOT NULL,
	TotalPrice DECIMAL(15, 2) NOT NULL,
	Discount DECIMAL(15, 2) NOT NULL default 0,
	CreationDate DATE default getdate(),
)

CREATE TABLE [OrderDetail] (
	Id BIGINT PRIMARY KEY NOT NULL,
	OrderId BIGINT FOREIGN KEY REFERENCES [Order](Id) NOT NULL,
	Price DECIMAL(15, 2) NOT NULL,
	Discount DECIMAL(15, 2) NOT NULL,
)

CREATE TABLE [Payment] (
	Id BIGINT PRIMARY KEY NOT NULL,
	UserId BIGINT FOREIGN KEY REFERENCES [User](Id) NOT NULL,
	Price DECIMAL(15, 2) NOT NULL,
	Bank NVARCHAR(100) NOT NULL,
	[Description] NVARCHAR(500) NOT NULL,
	IsCompleted Bit NOT NULL constraint df default 0,
	CompletionDate DATE,
)

CREATE TABLE [BuyCart] (
	Number BIGINT PRIMARY KEY NOT NULL,
)

CREATE TABLE [BoughtArtwork] (
	[Count] INT NOT NULL constraint countMin check([Count] > 0),
	UserId BIGINT FOREIGN KEY REFERENCES [User](Id) NOT NULL,
	ArtworkId BIGINT FOREIGN KEY REFERENCES [Artwork](Id) NOT NULL,
	PRIMARY KEY(UserId, ArtworkId)
)

CREATE TABLE [OrderDetail_Artwork] (
	[Count] INT NOT NULL,
	OrderDetailId BIGINT FOREIGN KEY REFERENCES [OrderDetail](Id) NOT NULL,
	ArtworkId BIGINT FOREIGN KEY REFERENCES [Artwork](Id) NOT NULL,
	PRIMARY KEY(OrderDetailId, ArtworkId)
)

CREATE TABLE [BuyCart_Info] (
	[Count] INT NOT NULL,
	BuyCartNo BIGINT FOREIGN KEY REFERENCES [BuyCart](Number) NOT NULL,
	ArtworkId BIGINT FOREIGN KEY REFERENCES [Artwork](Id) NOT NULL,
	PRIMARY KEY(BuyCartNo, ArtworkId)
)