USE [ArtStore]

INSERT INTO [dbo].[Person] (id , firstname , lastname , Gender , Birthdate)
VALUES 
(12345678, 'mmd' , 'mmdi' , 'male' , '2008-11-11' ),
(12293846, 'Maria', 'Anders', 'male' , '1971-02-02'),
(29213821, 'Ana', 'Trujillo', 'male' , '1956-11-19'),
(33219484, 'Antonio', 'Moreno', 'male' , '1968-05-14'),
(41234686, 'Thomas', 'Hardy', 'male' , '1956-02-07'),
(57397325, 'Christina', 'Berglund', 'male' , '1960-12-05'),
(67487994, 'Hanna', 'Moos', 'male' , '1956-01-06'),
(74299032, 'Frederique', 'Citeaux', 'male' , '1958-03-09'),
(83568356, 'Mart?n', 'Sommer', 'male' , '1952-12-02'),
(93567219, 'Laurence', 'Lebihan', 'male' , '1965-11-07'),
(10397602, 'Elizabeth', 'Lincoln', 'female' , '1966-06-14'),
(11365286, 'Victoria', 'Ashworth', 'female' , '1951-10-28'),
(12368216, 'Patricio', 'Simpson', 'female' , '1996-03-04'),
(13123457, 'Francisco', 'Chang', 'female' , '1990-08-31'),
(14373658, 'Yang', 'Wang', 'female' , '1990-05-31'),
(15172687, 'Pedro', 'Afonso', 'female' , '1994-10-10'),
(16384790, 'Elizabeth', 'Brown', 'female' , '1953-12-19'),
(17356822, 'Sven', 'Ottlieb', 'female' , '1994-05-04'),
(18625552, 'Janine', 'Labrune', 'female' , '1968-01-12'),
(19134132, 'Ann', 'Devon', 'female' , '1954-09-01'),
(20457568, 'Roland', 'Mendel', 'female' , '2017-07-05'),
(21157772, 'Aria', 'Cruz', 'female' , '1997-05-24'),
(22176539, 'Diego', 'Roel', 'female' , '2007-09-05'),
(23134345, 'Martine', 'Martine', 'male' , '2016-08-15'),
(24349766, 'Maria', 'Larsson', 'male' , '1948-07-20'),
(25098765, 'Peter', 'Franken', 'male' , '1999-01-30'),
(26866903, 'Carine', 'Schmitt', 'male' , '1991-03-01');

INSERT INTO [dbo].[Artist] ( id , personid , nickname , style , artworkcount , Deathdate )
VALUES
(1 , 21157772 , 'saye', 'cubism' , 30 , '2020-11-30' ),
(2 , 22176539 , 'negar', 'classic' , 24 , '2022-06-21' ),
(3 , 23134345 , 'andy', 'pop art' , 122 , '2021-09-25' ),
(4 , 24349766 , 'hura', 'surrealism' , 51 , '1999-09-16' ),
(5 , 25098765 , 'yas', 'expressionism' , 48 , '2019-12-10' ),
(6 , 26866903 , 'nick', 'impressionism' , 32 , '2020-01-28' )


INSERT INTO [dbo].[user] (id , personid, username , Email , Password , SignupDate)
VALUES
(1, 12345678, 'johndoe', 'johndoe@example.com', 'mysecretp', '1990-01-01'),
(2, 12293846, 'janedoe', 'janedoe@example.com', 'p@ssword', '1992-05-15'),
(3, 29213821, 'mikejones', 'mikejones@example.com', '123456', '1988-12-12'),
(4, 33219484,'sarahsmith', 'sarahsmith@example.com', 'abc123', '1995-08-23'),
(5, 41234686, 'emilywatson', 'emilywatson@example.com', 'qwertrty', '1998-02-14'),
(6, 57397325,  'jimmyjohns', 'jimmyjohns@example.com', 'letmeintt', '1983-11-27'),
(7, 67487994, 'liamjohnson', 'liamjohnson@example.com', 'password3', '2004-03-22'),
(8, 74299032, 'oliviasmith', 'oliviasmith@example.com', 'myp@sswod', '2003-07-11'),
(9, 83568356, 'noahwilliams', 'noahwilliams@example.com', 'qwerty13', '2005-05-01'),
(10, 93567219, 'emilyjones', 'emilyjones@example.com', 'letmein12', '2004-11-09'),
(11, 10397602, 'ethanbrown', 'ethanbrown@example.com', 'pssword3', '2003-02-18'),
(12, 11365286,'sophiarobinson', 'sophiarobinson@example.com', '12345678', '2005-09-07'),
(13, 12368216,'jacksondavis', 'jacksondavis@example.com', 'pasord456', '2003-12-15'),
(14, 13123457, 'emmawilson', 'emmawilson@example.com', 'mysword12', '2004-06-28'),
(15, 14373658, 'aidenmartin', 'aidenmartin@example.com', 'sword456', '2005-01-03'),
(16, 15172687, 'madisonlee', 'madisonlee@example.com', 'letmein456', '2003-04-12'),
(17, 16384790,'olivergarcia', 'olivergarcia@example.com', 'password78', '2004-08-30'),
(18, 17356822, 'avamartinez', 'avamartinez@example.com', 'mssword45', '2003-11-24'),
(19, 18625552,'lucaslopez', 'lucaslopez@example.com', 'qwerty789', '2005-02-17'),
(20, 19134132, 'isabellahernandez', 'isabellahernandez@example.com', 'letmein78', '2004-05-06'),
(21, 20457568,'masongonzalez', 'masongonzalez@example.com', 'psswor89', '2003-09-25');


INSERT INTO [dbo].[ArtCategory] ([Id], [Name], [AdditionDate]) 
VALUES 
	(1, 'Painting', '2023-06-01'),
	(2, 'Sculpture', '2023-06-02'),
	(3, 'Architecture', '2023-06-03'),
	(4, 'Literature', '2023-06-04'),
	(5, 'Music', '2023-06-05'),
	(6, 'Cinema', '2023-06-06');


INSERT INTO [dbo].[ArtSubCategory] ([Id], [CategoryId], [Name], [AdditionDate]) 
VALUES 
	(1, 1, 'Oil painting', '2023-06-05'),
	(2, 1, 'Watercolor painting', '2023-06-05'),
	(3, 1, 'Acrylic painting', '2023-06-05'),
	(4, 2, 'Stone sculpture', '2023-06-05'),
	(5, 2, 'Wood sculpture', '2023-06-05'),
	(6, 2, 'Metal sculpture', '2023-06-05'),
	(7, 3, 'Residential architecture', '2023-06-05'),
	(8, 3, 'Commercial architecture', '2023-06-05'),
	(9, 4, 'Poetry', '2023-06-05'),
	(10, 4, 'Novel', '2023-06-05'),
	(11, 5, 'Classical music', '2023-06-05'),
	(12, 5, 'Jazz music', '2023-06-05'),
	(13, 6, 'Action movie', '2023-06-05'),
	(14, 6, 'Comedy movie', '2023-06-05'),
	(15, 6, 'Musical theater', '2023-06-05');


INSERT INTO [dbo].[Artwork] (Id, ArtistId, CategoryId, SubCategoryId, Name, Price, Description, Style, Cover, AdditionDate, CreationDate)
VALUES 
(1, 1, 1, 1, 'Mona Lisa', 1000000.00, 'A portrait of Lisa Gherardini, wife of Francesco del Giocondo', 'Renaissance', 'mona-lisa.jpg', '2022-01-01', '2012-01-01'),
(2, 2, 2, 4, 'The Starry Night', 2000000.00, 'A view of the village of Saint-R�my-de-Provence from Vincent van Goghs asylum room', 'Post-Impressionism', 'starry-night.jpg', '2022-01-02', '2022-01-02'),
(3, 3, 3, 7, 'Girl with a Pearl Earring', 3000000.00, 'A portrait of a young woman wearing a turban, by Johannes Vermeer', 'Baroque', 'girl-pearl-earring.jpg', '2022-01-03', '1999-01-03'),
(4, 4, 4, 9, 'The Persistence of Memory', 4000000.00, 'A surrealist landscape with melting clocks, by Salvador Dal�', 'Surrealism', 'persistence-memory.jpg', '2022-01-04', '1990-01-04'),
(5, 1, 1, 2, 'Les Demoiselles dAvignon', 5000000.00, 'A depiction of five prostitutes in a brothel, by Pablo Picasso', 'Cubism', 'demoiselles-avignon.jpg', '2022-01-05', '1899-01-05'),
(6, 1, 2, 5, 'The Birth of Venus', 6000000.00, 'A depiction of the goddess Venus emerging from the sea, by Sandro Botticelli', 'Renaissance', 'birth-venus.jpg', '2022-01-06', '1960-01-06'),
(7, 2, 3, 8, 'Water Lilies', 7000000.00, 'A series of impressionist paintings of water lilies and their reflections, by Claude Monet', 'Impressionism', 'water-lilies.jpg', '2022-01-07', '1900-01-07'),
(8, 3, 4, 10, 'The Scream', 8000000.00, 'A depiction of a person screaming in agony, by Edvard Munch', 'Expressionism', 'scream.jpg', '2022-01-08', '1934-01-08'),
(9, 4, 1, 3, 'The Kiss', 9000000.00, 'A depiction of lovers embracing, by Gustav Klimt', 'Art Nouveau', 'kiss.jpg', '2022-01-09', '1985-01-09'),
(10, 2, 2, 6, 'Guernica', 10000000.00, 'A depiction of the bombing of the town of Guernica during the Spanish Civil War, by Pablo Picasso', 'Cubism', 'guernica.jpg', '2022-01-10', '1987-01-10'),
(11, 3, 3, 7, 'The Great Wave off Kanagawa', 11000000.00, 'A woodblock print of a giant wave with boats in the foreground, by Katsushika Hokusai', 'Ukiyo-e', 'great-wave.jpg', '2022-01-11', '1897-01-11'),
(12, 3, 4, 9, 'The Night Watch', 12000000.00, 'A group portrait of a city guard, by Rembrandt van Rijn', 'Baroque', 'night-watch.jpg', '1943-01-12', '2022-01-12'),
(13, 4, 1, 1, 'The David', 13000000.00, 'A marble statue of the biblical hero David, by Michelangelo', 'Renaissance', 'david.jpg', '1911-01-13', '2022-01-13'),
(14, 1, 2, 4, 'The Birth of Adam', 14000000.00, 'A fresco painting of God giving life to Adam, by Michelangelo', 'Renaissance', 'birth-of-adam.jpg', '2022-01-14', '1924-01-14'),
(15, 1, 3, 8, 'The Creation of Adam', 15000000.00, 'A fresco painting of God creating Adam, by Michelangelo', 'Renaissance', 'creation-of-adam.jpg', '2022-01-15', '1955-01-15'),
(16, 1, 4, 10, 'The Persistence of Memory II', 16000000.00, 'A surrealist landscape with melting clocks, by Salvador Dal�', 'Surrealism', 'persistence-memory-2.jpg', '2022-01-16', '1992-01-16'),
(17, 4, 1, 2, 'The Birth of Venus II', 17000000.00, 'A depiction of the goddess Venus emerging from the sea, by Sandro Botticelli', 'Renaissance', 'birth-venus-2.jpg', '2022-01-17', '1878-01-17'),
(18, 3, 2, 4, 'The Thinker', 18000000.00, 'A bronze statue of a man in deep thought, by Auguste Rodin', 'Symbolism', 'thinker.jpg', '2022-01-18', '1957-01-18'),
(19, 3, 3, 8, 'The Last Supper', 19000000.00, 'A mural painting of Jesus Christ and his disciples having their last meal, by Leonardo da Vinci', 'Renaissance', 'last-supper.jpg', '2022-01-19', '1970-01-19'),
(20, 2, 4, 9, 'The Mona Lisa II', 20000000.00, 'A portrait of Lisa Gherardini, wife of Francesco del Giocondo', 'Renaissance', 'mona-lisa-2.jpg', '2022-01-20', '1990-01-20'),

(21, 5, 5, 11, 'Thriller', 500000.00, 'The best-selling album of all time, by Michael Jackson', 'Pop', 'thriller.jpg', '2022-01-21', '2022-01-21'),
(22, 5, 5, 12, 'The Joshua Tree', 600000.00, 'The fifth studio album by U2, inspired by American roots music and the bands experiences on tour', 'Rock', 'joshua-tree.jpg', '2022-01-22', '2022-01-22'),
(23, 5, 5, 11, 'The Chronic', 700000.00, 'The debut studio album by Dr. Dre, featuring Snoop Dogg, Nate Dogg, and other West Coast rappers', 'Hip hop', 'the-chronic.jpg', '2022-01-23', '2022-01-23'),
(24, 5, 5, 12, 'Back in Black', 800000.00, 'The seventh studio album by AC/DC, featuring hits like "Hells Bells" and "Back in Black"', 'Hard rock', 'back-in-black.jpg', '2022-01-24', '2022-01-24'),
(25, 5, 5, 11, 'Purple Rain', 900000.00, 'The sixth studio album by Prince and the soundtrack to the film of the same name, featuring hits like "When Doves Cry" and "Purple Rain"', 'Pop rock', 'purple-rain.jpg', '2022-01-25', '2022-01-25'),
(26, 5, 5, 12, 'Bad', 300000.00, 'The seventh studio album by Michael Jackson, featuring hits like "The Way You Make Me Feel" and "Man in the Mirror"', 'Pop', 'bad.jpg', '2022-02-01', '2022-02-01'),
(27, 4, 4, 9, 'The Dark Side of the Moon', 400000.00, 'The eighth studio album by Pink Floyd, featuring hits like "Money" and "Time"', 'Progressive rock', 'dark-side-of-the-moon.jpg', '2022-02-02', '2022-02-02'),
(28, 4, 4, 10, 'The College Dropout', 500000.00, 'The debut studio album by Kanye West, featuring hits like "Through the Wire" and "All Falls Down"', 'Hip hop', 'college-dropout.jpg', '2022-02-03', '2022-02-03'),
(29, 4, 4, 10, 'Appetite for Destruction', 600000.00, 'The debut studio album by Guns N Roses, featuring hits like "Sweet Child o Mine" and "Welcome to the Jungle"', 'Hard rock', 'appetite-for-destruction.jpg', '2022-02-04', '2022-02-04'),
(30, 4, 4, 9, 'Nevermind', 700000.00, 'The second studio album by Nirvana, featuring hits like "Smells Like Teen Spirit" and "Come as You Are"', 'Grunge', 'nevermind.jpg', '2022-02-05', '2022-02-05'),

(31, 6, 6, 13, 'The Dark Knight', 1500.00, 'Original artwork inspired by the movie', 'Contemporary', '7nBZGQ1.jpg', '2022-01-01', '2021-10-01'),
(32, 6, 6, 14, 'E.T. the Extra-Terrestrial', 1200.00, 'Original artwork inspired by the movie', 'Pop Art', '5qJXxvP.jpg', '2022-01-02', '2021-09-01'),
(33, 6, 6, 15, 'The Matrix', 1800.00, 'Original artwork inspired by the movie', 'Abstract', '8nJcIeC.jpg', '2022-01-03', '2021-08-01'),
(34, 6, 6, 13, 'Indiana Jones and the Raiders of the Lost Ark', 2000.00, 'Original artwork inspired by the movie', 'Realism', 'uQxu8XZ.jpg', '2022-01-04', '2021-07-01'),
(35, 6, 6, 14, 'Forrest Gump', 1300.00, 'Original artwork inspired by the movie', 'Impressionism', 'Io5b4dr.jpg', '2022-01-05', '2021-06-01');


INSERT INTO [Order] (Id, UserId, FinalPrice, TotalPrice, Discount, CreationDate)
VALUES
(1, 1, 19.99, 24.99, 5.00, '2023-06-11'),
(2, 2, 29.99, 34.99, 5.00, '2023-06-12'),
(3, 3, 39.99, 44.99, 5.00, '2023-06-13'),
(4, 4, 49.99, 54.99, 5.00, '2023-06-14'),
(5, 5, 59.99, 64.99, 5.00, '2023-06-15'),
(6, 6, 69.99, 74.99, 5.00, '2023-06-16'),
(7, 7, 79.99, 84.99, 5.00, '2023-06-17'),
(8, 8, 89.99, 94.99, 5.00, '2023-06-18'),
(9, 9, 99.99, 104.99, 5.00, '2023-06-19'),
(10, 10, 109.99, 114.99, 5.00, '2023-06-20'),
(11, 11, 119.99, 124.99, 5.00, '2023-06-21'),
(12, 12, 129.99, 134.99, 5.00, '2023-06-22'),
(13, 13, 139.99, 144.99, 5.00, '2023-06-23'),
(14, 14, 149.99, 154.99, 5.00,'2023-06-24'),
(15 ,15 ,159.99 ,164.99 ,5.00 ,'2023-06-25'),
(16 ,16 ,169.99 ,174.99 ,5.00 ,'2023-06-26'),
(17 ,17 ,179.99 ,184.99 ,5.00 ,'2023-06-27'),
(18 ,18 ,189.99 ,194.99 ,5.00 ,'2023-06-28'),
(19 ,19 ,199.99 ,204.99 ,5.00 ,'2023-06-29'),
(20 ,20 ,209.99 ,214.99 ,5.00 ,'2023-06-30'),
(21 ,21 ,219.99 ,224.99 ,5.00 ,'2023-07-01'),
(22 ,1 ,229.99 ,234.99 ,5.00 ,'2023-07-02'),
(23 ,2 ,239.99 ,244.99 ,5.00 ,'2023-07-03'),
(24 ,3 ,249.99 ,254.99 ,5.00 ,'2023-07-04'),
(25 ,4 ,259.99 ,264.99 ,5.00 ,'2023-07-05'),
(26 ,5 ,269.99 ,274.99 ,5.00 ,'2023-07-06'),
(27 ,6 ,279.99 ,284.99 ,5.00 ,'2023-07-07'),
(28 ,7 ,289.99 ,294.99 ,5.00 ,'2023-07-08'),
(29 ,8 ,299.99 ,304.99 ,5.00 ,'2023-07-09');


INSERT INTO [OrderDetail] (Id, OrderId, Price, Discount)
SELECT 2 * o.Id - 1, o.Id, o.TotalPrice / 2, o.Discount / 2
FROM [Order] o
UNION ALL
SELECT 2 * o.Id, o.Id, o.TotalPrice / 2, o.Discount / 2
FROM [Order] o;


INSERT INTO [OrderDetail_Artwork] ([Count], OrderDetailId, ArtworkId)
SELECT 1, od.Id, a.Id
FROM [OrderDetail] od
CROSS JOIN [Artwork] a
WHERE a.Id IN (SELECT TOP 2 Id FROM [Artwork] WHERE Id IN ( SELECT FLOOR((od.id*2*od.id) % 35)+1))


INSERT INTO Payment (Id, UserId, Price, Bank, Description, IsCompleted, CompletionDate)
VALUES
    (1, 1, 100.00, 'Bank of America', 'Payment for services rendered', 0, '2023-06-01'),
    (2, 2, 50.00, 'Wells Fargo', 'Payment for goods purchased', 0, '2023-06-02'),
    (3, 3, 75.00, 'Chase', 'Payment for rent', 0, '2023-06-03'),
    (4, 4, 200.00, 'Citibank', 'Payment for consulting services', 0, '2023-06-04'),
    (5, 5, 150.00, 'US Bank', 'Payment for software development services', 0, '2023-06-05'),
	(6, 6, 100.00, 'Bank of America', 'Payment for services rendered', 0, '2023-06-06'),
    (7, 7, 50.00, 'Wells Fargo', 'Payment for goods purchased', 0, '2023-06-07'),
    (8, 8, 75.00, 'Chase', 'Payment for rent', 0, '2023-06-08'),
    (9, 9, 200.00, 'Citibank', 'Payment for consulting services', 0, '2023-06-09'),
    (10, 10, 150.00, 'US Bank', 'Payment for software development services', 0, '2023-06-10'),
    (11, 11, 100.00, 'Bank of America', 'Payment for services rendered', 0, '2023-06-11'),
    (12, 12, 50.00, 'Wells Fargo', 'Payment for goods purchased', 0, '2023-06-12'),
    (13, 13, 75.00, 'Chase', 'Payment for rent', 0, '2023-06-13'),
    (14, 14, 200.00, 'Citibank', 'Payment for consulting services', 0, '2023-06-14'),
    (15, 15, 150.00, 'US Bank', 'Payment for software development services', 0,'2023-06-15'),
    (16 ,16 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0 ,'2023-06-16'),
    (17 ,17 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0 ,'2023-06-17'),
    (18 ,18 ,75.00 ,'Chase' ,'Payment for rent' ,0 ,'2023-06-18'),
    (19 ,19 ,200.00 ,'Citibank' ,'Payment for consulting services' ,0 ,'2023-06-19'),
    (20 ,20 ,150.00 ,'US Bank' ,'Payment for software development services' ,0 ,'2023-06-20'),
    (21 ,21 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0 ,'2023-06-21'),
    (22 ,2 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0 ,'2023-06-22'),
    (23 ,3 ,75.00 ,'Chase' ,'Payment for rent' ,0 ,'2023-06-23'),
    (24 ,4 ,200.00 ,'Citibank' ,'Payment for consulting services' ,0 ,'2023-06-24'),
    (25 ,5 ,150.00 ,'US Bank' ,'Payment for software development services' ,0,'2023-06-25'),
    (26 ,6 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0,'2023-06-26'),
    (27 ,7 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0,'2023-06-27'),
    (28 ,8 ,75.00 ,'Chase' ,'Payment for rent' ,0,'2023-06-28'),
    (29 ,9 ,200.00 ,'Citibank' ,'Payment for consulting services' ,0,'2023-06-29'),
    (30 ,1 ,150.00 ,'US Bank' ,'Payment for software development services' ,0,'2023-06-30'),
	(31 ,11 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0 ,'2023-07-06'),
    (32 ,12 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0 ,'2023-07-07'),
    (33 ,13 ,75.00 ,'Chase' ,'Payment for rent' ,0 ,'2023-07-08'),
    (34 ,14 ,200.00 ,'Citibank' ,'Payment for consulting services' ,0 ,'2023-07-09'),
    (35 ,15 ,150.00 ,'US Bank' ,'Payment for software development services' ,0,'2023-07-10'),
    (36 ,16 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0,'2023-07-11'),
    (37 ,17 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0,'2023-07-12'),
    (38 ,18 ,75.00 ,'Chase' ,'Payment for rent' ,0,'2023-07-13'),
    (39 ,19 ,200.00 ,'Citibank' ,'Payment for consulting services' ,0,'2023-07-14'),
    (40 ,20 ,150.00 ,'US Bank' ,'Payment for software development services' ,0,'2023-07-15'),
    (41 ,21 ,100.00 ,'Bank of America' ,'Payment for services rendered' ,0,'2023-07-16'),
    (42 ,1 ,50.00 ,'Wells Fargo' ,'Payment for goods purchased' ,0,'2023-07-17'),
    (43 ,1 ,75.00 ,'Chase' ,'Payment for rent' ,0,'2023-07-18'),
    (44 ,2 ,200.00 ,'Citibank' ,'Payment for consulting services',0,'2023-07-19'),
    (45 ,3 ,150.00 ,'US Bank','Payment for software development services',0,'2023-07-20'),
    (46 ,4 ,100.00,'Bank of America','Payment for services rendered',0,'2023-07-21'),
    (47 ,5 ,50.00,'Wells Fargo','Payment for goods purchased',0,'2023-07-22'),
    (48 ,6 ,75.00,'Chase','Payment for rent',0,'2023-07-23'),
    (49 ,7 ,200.00,'Citibank','Payment for consulting services',0,'2023-07-24'),
    (40 ,8 ,150.00,'US Bank','Payment for software development services',0,'2023-07-25');


INSERT INTO BuyCart (Number)
VALUES
    (1),
    (2),
    (3),
    (4),
    (5),
    (6),
    (7),
    (8),
    (9),
    (10),
    (11),
    (12),
    (13),
    (14),
    (15),
    (16),
    (17),
    (18),
    (19),
    (20),
    (21);


INSERT INTO BoughtArtwork ([Count], UserId, ArtworkId)
VALUES
    (1, 1, 1),
    (1, 2, 2),
    (1, 3, 3),
    (1, 4, 4),
    (1, 5, 5),
    (1, 6, 6),
    (1, 7, 7),
    (1, 8, 8),
    (1, 9, 9),
    (1, 10, 10),
	(1, 11, 11),
    (1, 12, 12),
    (1, 13, 13),
    (1, 14, 14),
    (1, 15, 15),
    (1, 16, 16),
    (1, 17, 17),
    (1, 18, 18),
    (1, 19, 19),
    (1, 20, 20),
	(1, 21, 21),
    (1, 1, 22),
    (1, 1, 23),
    (1, 2, 24),
    (1, 3, 25),
    (1, 4, 26),
    (1, 5, 27),
    (1, 6, 28),
    (1, 7, 29),
    (1, 8, 30),
    (1, 9, 31),
    (1, 10, 32),
    (1, 11, 33),
    (1, 12, 34),
    (1, 13, 35),
    (1, 14, 35),
    (1, 15, 1),
    (1, 16, 2),
    (1, 17, 3),
    (1, 18, 4);


INSERT INTO BuyCart_Info (Count, BuyCartNo, ArtworkId)
VALUES 
(1, 1, 1),
(1, 2, 2),
(1, 3, 3),
(1, 4, 4),
(1, 5, 5),
(1, 6, 6),
(1, 7, 7),
(1, 8, 8),
(1, 9, 9),
(1, 10, 10),
(1, 11, 11),
(1, 12, 12),
(1, 13, 13),
(1, 14, 14),
(1, 15, 15),
(1, 16, 16),
(1, 17, 17),
(1, 18, 18),
(1, 19, 19),
(1, 20, 20),
(1, 21, 21);

