use [ArtStore];

-- 1: completed payments
select Username, Email, [Price], Description
from Payment join [User] on UserId = [User].Id
where IsCompleted = 1
order by [Price] desc;

-- 2: bought artworks
select [Artwork].[Name], [Description]
from Artwork join BoughtArtwork on ArtworkId = Artwork.Id

-- 3: all categories with theirs sub categories
select ArtCategory.[Name] as category, [ArtSubCategory].[Name] as subcategory
from ArtCategory left join ArtSubCategory on CategoryId = ArtCategory.Id
order by ArtCategory.Id

-- 4: list of users
select Id, UserName as username, Email
from [User];

-- 5: artists with more than 8 artworks
select *
from Artist
where ArtWorkCount > 8;

-- 6: arts done in a different style than the artist's main style
select (concat(Person.FirstName, ' ', Person.LastName)) as [artist_name],  Artwork.[Name] as art_name, Artwork.Style as style
from Artist join Artwork on ArtistId = Artist.Id
join Person on PersonId = Person.Id
where Artist.Style != Artwork.Style;

-- 7: all discounted orders
select [Order].Id, [Order].FinalPrice, [Order].CreationDate
from [Order]
where Discount > 0;

-- 8: artworks with unknown creation date
select Artwork.[Name], Artwork.[Description]
from Artwork
where CreationDate = null;

-- 9: all non-empty buycarts
select distinct Number
from BuyCart join BuyCart_Info on BuyCartNo = Number
order by Number

-- 10: all orders from 10 years ago or older ordered by the oldest
select [Order].Id, [Order].CreationDate
from [Order]
where year(cast(getdate() as date) - [Order].CreationDate) >= 10
order by [Order].CreationDate;

-- 11: all artworks of a subArtCategory (Oil painting) order by  
select [Name]
from [ArtWork]
where SubCategoryId = (SELECT [Id] FROM ArtSubCategory WHERE [Name] = 'oil painting');

-- 12: all artworks with price more than 10000000 dollars sorting decending by price
SELECT *
FROM [ArtWork]
WHERE Price >= 10000000
ORDER BY Price DESC

-- 13: names of people who has more than 1 orders
SELECT Person.[FirstName]
FROM Person
JOIN [Order] ON Person.Id = [order].UserId
GROUP BY Person.[FirstName]
HAVING COUNT(*) > 1;

-- 14: names of people who has successful payment
SELECT Person.[FirstName]
FROM Person
JOIN [Payment] ON Person.Id = [Payment].UserId
WHERE [IsCompleted] = 1
GROUP BY Person.[FirstName]

-- 15: nicknames of Artist who has more than one artwork in the art store
SELECT Artist.NickName
FROM Artist
Join [Artwork] ON Artist.Id = Artwork.ArtistId
GROUP BY Artwork.Id
HAVING COUNT(*) > 1;

-- 16: nicknames of Artist who is dead
SELECT NickName
FROM Artist
WHERE Deathdate IS NOT NULL;

-- 17: Bank of unsuccessful payments sorting by latest
SELECT Bank
FROM Payment
WHERE IsCompleted = 0
ORDER BY CompletionDate DESC;

-- 18: name of Art categories with more than one art sub category
SELECT ArtCategory.[Name]
FROM ArtCategory
Join ArtSubCategory ON ArtCategory.Id = ArtSubCategory.CategoryId
GROUP BY ArtCategory.[Name]
HAVING COUNT(*) > 1;

-- 19: name of artworks which added to art store in less than 2 years from theyr creation
SELECT [Name]
FROM Artwork
WHERE DATEDIFF(day, AdditionDate, CreationDate) < 730;

use [ArtStore];
-- 20: name of artworks boutght by a person (with firstName Elizabeth)
SELECT Artwork.[Name]
FROM BoughtArtwork
Join Person ON Person.id = BoughtArtwork.UserId
join Artwork ON Artwork.id = BoughtArtwork.ArtworkId
WHERE Person.FirstName = 'Elizabeth'
